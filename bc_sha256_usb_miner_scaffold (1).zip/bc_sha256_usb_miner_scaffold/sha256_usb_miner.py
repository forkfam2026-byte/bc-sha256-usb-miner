#!/usr/bin/env python3
"""
Black Caesar SHA-256 USB Miner Scaffold
======================================

Legit-use scope:
- Educational SHA-256 / double-SHA-256 proof-of-work mining.
- USB-aware device scanning for owned USB serial devices.
- Explicit user-run only. No autorun. No stealth. No persistence.
- No pool credentials. No wallet handling. No botnet behavior.
- Does NOT speak proprietary ASIC mining protocols.

For real Bitcoin USB ASIC mining, use maintained mining software such as cgminer
or a vendor-supported tool for the specific ASIC. This scaffold gives Ninja a
safe, logged, testable proof-of-work core and USB detection layer.

Examples:
    python sha256_usb_miner.py scan
    python sha256_usb_miner.py benchmark --seconds 10 --workers 4
    python sha256_usb_miner.py mine --challenge "BLACK_CAESAR_CROWN_LAW" --bits 24 --workers 4
    python sha256_usb_miner.py mine --challenge "USB_BOUND_RUN" --bits 22 --usb-index 0 --workers 2

Author posture:
    prove-before-move, log-before-claim, owned hardware only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import platform
import queue
import signal
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


try:
    from serial.tools import list_ports
except Exception:  # pragma: no cover
    list_ports = None


APP_NAME = "bc_sha256_usb_miner_scaffold"
LEDGER_DIR = Path("data") / "sha256_miner_ledger"


# -----------------------------
# Time / serialization helpers
# -----------------------------

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def monotonic_ns() -> int:
    return time.monotonic_ns()


def json_dumps(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


# -----------------------------
# USB scanning
# -----------------------------

@dataclass(frozen=True)
class UsbDeviceInfo:
    index: int
    device: str
    name: Optional[str]
    description: Optional[str]
    hwid: Optional[str]
    manufacturer: Optional[str]
    product: Optional[str]
    serial_number: Optional[str]
    vid: Optional[int]
    pid: Optional[int]

    def stable_fingerprint(self) -> str:
        """
        Non-secret device fingerprint for audit binding.
        This is not authentication. It only records which local USB device
        the operator chose at run start.
        """
        payload = {
            "device": self.device,
            "manufacturer": self.manufacturer,
            "product": self.product,
            "serial_number": self.serial_number,
            "vid": self.vid,
            "pid": self.pid,
        }
        return hashlib.sha256(json_dumps(payload).encode("utf-8")).hexdigest()


def scan_usb_devices() -> List[UsbDeviceInfo]:
    if list_ports is None:
        return []

    devices: List[UsbDeviceInfo] = []
    for idx, port in enumerate(list_ports.comports()):
        devices.append(
            UsbDeviceInfo(
                index=idx,
                device=getattr(port, "device", "") or "",
                name=getattr(port, "name", None),
                description=getattr(port, "description", None),
                hwid=getattr(port, "hwid", None),
                manufacturer=getattr(port, "manufacturer", None),
                product=getattr(port, "product", None),
                serial_number=getattr(port, "serial_number", None),
                vid=getattr(port, "vid", None),
                pid=getattr(port, "pid", None),
            )
        )
    return devices


def print_usb_scan(devices: List[UsbDeviceInfo]) -> None:
    if list_ports is None:
        print("pyserial is not installed. Run: pip install -r requirements.txt")
        return

    if not devices:
        print("No USB serial devices detected.")
        return

    print("Detected USB serial devices:")
    for d in devices:
        print(f"[{d.index}] {d.device}")
        print(f"    description : {d.description}")
        print(f"    manufacturer: {d.manufacturer}")
        print(f"    product     : {d.product}")
        print(f"    serial      : {d.serial_number}")
        print(f"    VID:PID     : {fmt_vid_pid(d.vid, d.pid)}")
        print(f"    fingerprint : {d.stable_fingerprint()}")


def fmt_vid_pid(vid: Optional[int], pid: Optional[int]) -> str:
    if vid is None or pid is None:
        return "unknown"
    return f"{vid:04x}:{pid:04x}"


# -----------------------------
# SHA-256 mining core
# -----------------------------

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def double_sha256(data: bytes) -> bytes:
    return sha256(sha256(data))


def leading_zero_bits(digest: bytes) -> int:
    """
    Count leading zero bits in a digest.
    """
    count = 0
    for b in digest:
        if b == 0:
            count += 8
            continue
        # Count leading zeros in this nonzero byte.
        count += 8 - b.bit_length()
        break
    return count


def meets_difficulty(digest: bytes, bits: int) -> bool:
    return leading_zero_bits(digest) >= bits


def build_work_payload(
    challenge: str,
    nonce: int,
    usb_fingerprint: Optional[str],
    algorithm: str,
) -> bytes:
    """
    Deterministic work payload.

    This is not a Bitcoin block header. It is an educational proof-of-work
    payload designed to be auditable and safe.
    """
    payload = {
        "algorithm": algorithm,
        "challenge": challenge,
        "nonce": nonce,
        "usb_fingerprint": usb_fingerprint,
    }
    return json_dumps(payload).encode("utf-8")


@dataclass(frozen=True)
class MiningResult:
    challenge: str
    nonce: int
    hash_hex: str
    difficulty_bits: int
    leading_zero_bits: int
    algorithm: str
    attempts: int
    worker_id: int
    started_at: str
    found_at: str
    elapsed_seconds: float
    usb_bound: bool
    usb_fingerprint: Optional[str]
    host: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class BenchmarkResult:
    algorithm: str
    workers: int
    seconds: float
    attempts: int
    hashes_per_second: float
    started_at: str
    ended_at: str
    host: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def host_fingerprint() -> Dict[str, Any]:
    return {
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "cpu_count": os.cpu_count(),
        "pid": os.getpid(),
        "app": APP_NAME,
    }


def miner_worker(
    worker_id: int,
    challenge: str,
    bits: int,
    algorithm: str,
    usb_fingerprint: Optional[str],
    start_nonce: int,
    stride: int,
    throttle_ms: int,
    result_queue: "mp.Queue[Dict[str, Any]]",
    stop_event: "mp.Event",
) -> None:
    attempts = 0
    nonce = start_nonce
    started_mono = time.monotonic()
    started_at = utc_now_iso()

    try:
        while not stop_event.is_set():
            payload = build_work_payload(
                challenge=challenge,
                nonce=nonce,
                usb_fingerprint=usb_fingerprint,
                algorithm=algorithm,
            )

            if algorithm == "sha256":
                digest = sha256(payload)
            elif algorithm == "double-sha256":
                digest = double_sha256(payload)
            else:
                raise ValueError(f"Unsupported algorithm: {algorithm}")

            attempts += 1

            if meets_difficulty(digest, bits):
                elapsed = time.monotonic() - started_mono
                result = MiningResult(
                    challenge=challenge,
                    nonce=nonce,
                    hash_hex=digest.hex(),
                    difficulty_bits=bits,
                    leading_zero_bits=leading_zero_bits(digest),
                    algorithm=algorithm,
                    attempts=attempts,
                    worker_id=worker_id,
                    started_at=started_at,
                    found_at=utc_now_iso(),
                    elapsed_seconds=elapsed,
                    usb_bound=usb_fingerprint is not None,
                    usb_fingerprint=usb_fingerprint,
                    host=host_fingerprint(),
                )
                stop_event.set()
                result_queue.put(result.to_dict())
                return

            nonce += stride

            if throttle_ms > 0 and attempts % 1024 == 0:
                time.sleep(throttle_ms / 1000.0)

    except KeyboardInterrupt:
        stop_event.set()
    except Exception as exc:
        stop_event.set()
        result_queue.put(
            {
                "error": str(exc),
                "worker_id": worker_id,
                "attempts": attempts,
                "nonce": nonce,
                "at": utc_now_iso(),
            }
        )


def benchmark_worker(
    worker_id: int,
    seconds: float,
    algorithm: str,
    stop_event: "mp.Event",
    result_queue: "mp.Queue[Dict[str, Any]]",
) -> None:
    attempts = 0
    deadline = time.monotonic() + seconds
    nonce = worker_id
    challenge = "BENCHMARK"

    while not stop_event.is_set() and time.monotonic() < deadline:
        payload = build_work_payload(challenge, nonce, None, algorithm)
        if algorithm == "sha256":
            sha256(payload)
        elif algorithm == "double-sha256":
            double_sha256(payload)
        else:
            result_queue.put({"error": f"Unsupported algorithm: {algorithm}", "worker_id": worker_id})
            return
        attempts += 1
        nonce += 1

    result_queue.put({"worker_id": worker_id, "attempts": attempts})


# -----------------------------
# Ledger
# -----------------------------

class JsonlLedger:
    """
    Append-only JSONL ledger.

    This is intentionally simple and local. Each event includes a previous
    event hash so the log can be verified later.
    """

    def __init__(self, ledger_dir: Path = LEDGER_DIR) -> None:
        self.ledger_dir = ledger_dir
        self.ledger_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self.path = self.ledger_dir / f"mining_ledger_{stamp}.jsonl"
        self._last_hash: Optional[str] = None

    @staticmethod
    def event_hash(event: Dict[str, Any]) -> str:
        event_without_hash = {k: v for k, v in event.items() if k != "event_hash"}
        return hashlib.sha256(json_dumps(event_without_hash).encode("utf-8")).hexdigest()

    def append(self, event_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        event = {
            "event_type": event_type,
            "created_at": utc_now_iso(),
            "monotonic_ns": monotonic_ns(),
            "prev_hash": self._last_hash,
            "payload": payload,
        }
        event["event_hash"] = self.event_hash(event)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, sort_keys=True) + "\n")
        self._last_hash = event["event_hash"]
        return event

    def verify(self) -> bool:
        prev_hash = None
        if not self.path.exists():
            return False

        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                event = json.loads(line)
                if event.get("prev_hash") != prev_hash:
                    return False
                expected = self.event_hash(event)
                if event.get("event_hash") != expected:
                    return False
                prev_hash = event["event_hash"]
        return True


# -----------------------------
# Commands
# -----------------------------

def validate_bits(bits: int) -> None:
    if bits < 1:
        raise ValueError("--bits must be at least 1")
    if bits > 32:
        raise ValueError(
            "--bits above 32 can run for a long time on CPU. "
            "For this scaffold, keep it <= 32."
        )


def resolve_usb_binding(usb_index: Optional[int]) -> Optional[UsbDeviceInfo]:
    if usb_index is None:
        return None

    devices = scan_usb_devices()
    if usb_index < 0 or usb_index >= len(devices):
        raise ValueError(f"No USB device at index {usb_index}. Run: python sha256_usb_miner.py scan")
    return devices[usb_index]


def command_scan(_: argparse.Namespace) -> int:
    print_usb_scan(scan_usb_devices())
    return 0


def command_benchmark(args: argparse.Namespace) -> int:
    workers = clamp_workers(args.workers)
    started_at = utc_now_iso()
    started = time.monotonic()

    stop_event = mp.Event()
    result_queue: "mp.Queue[Dict[str, Any]]" = mp.Queue()

    procs = [
        mp.Process(
            target=benchmark_worker,
            args=(i, args.seconds, args.algorithm, stop_event, result_queue),
            daemon=True,
        )
        for i in range(workers)
    ]

    for p in procs:
        p.start()

    attempts = 0
    completed = 0
    while completed < workers:
        try:
            msg = result_queue.get(timeout=args.seconds + 5)
            if "error" in msg:
                print(f"Worker error: {msg['error']}", file=sys.stderr)
                stop_event.set()
                return 2
            attempts += int(msg.get("attempts", 0))
            completed += 1
        except queue.Empty:
            stop_event.set()
            break

    for p in procs:
        p.join(timeout=1)

    elapsed = max(time.monotonic() - started, 0.000001)
    result = BenchmarkResult(
        algorithm=args.algorithm,
        workers=workers,
        seconds=elapsed,
        attempts=attempts,
        hashes_per_second=attempts / elapsed,
        started_at=started_at,
        ended_at=utc_now_iso(),
        host=host_fingerprint(),
    )

    ledger = JsonlLedger()
    ledger.append("benchmark", result.to_dict())
    ok = ledger.verify()

    print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
    print(f"ledger: {ledger.path}")
    print(f"ledger_verified: {ok}")
    return 0 if ok else 3


def command_mine(args: argparse.Namespace) -> int:
    validate_bits(args.bits)
    workers = clamp_workers(args.workers)
    usb_device = resolve_usb_binding(args.usb_index)
    usb_fingerprint = usb_device.stable_fingerprint() if usb_device else None

    ledger = JsonlLedger()
    ledger.append(
        "run_started",
        {
            "challenge": args.challenge,
            "bits": args.bits,
            "algorithm": args.algorithm,
            "workers": workers,
            "usb_device": asdict(usb_device) if usb_device else None,
            "usb_fingerprint": usb_fingerprint,
            "safety": {
                "explicit_user_run": True,
                "autorun": False,
                "stealth": False,
                "pool_credentials": False,
                "wallet_handling": False,
            },
            "host": host_fingerprint(),
        },
    )

    stop_event = mp.Event()
    result_queue: "mp.Queue[Dict[str, Any]]" = mp.Queue()

    procs = [
        mp.Process(
            target=miner_worker,
            args=(
                i,
                args.challenge,
                args.bits,
                args.algorithm,
                usb_fingerprint,
                i,
                workers,
                args.throttle_ms,
                result_queue,
                stop_event,
            ),
            daemon=True,
        )
        for i in range(workers)
    ]

    def handle_sigint(signum: int, frame: Any) -> None:
        stop_event.set()

    signal.signal(signal.SIGINT, handle_sigint)

    print("Mining started.")
    print(f"challenge : {args.challenge}")
    print(f"algorithm : {args.algorithm}")
    print(f"difficulty: {args.bits} leading zero bits")
    print(f"workers   : {workers}")
    print(f"usb_bound : {usb_fingerprint is not None}")
    if usb_device:
        print(f"usb       : [{usb_device.index}] {usb_device.device} {usb_device.description}")
    print("Press Ctrl+C to stop.")

    started = time.monotonic()
    for p in procs:
        p.start()

    result: Optional[Dict[str, Any]] = None
    try:
        while time.monotonic() - started < args.timeout_seconds:
            try:
                msg = result_queue.get(timeout=0.5)
                if "error" in msg:
                    ledger.append("worker_error", msg)
                    print(json.dumps(msg, indent=2, sort_keys=True), file=sys.stderr)
                    return 2
                result = msg
                break
            except queue.Empty:
                pass
    finally:
        stop_event.set()
        for p in procs:
            p.join(timeout=1)

    if result is None:
        event = ledger.append(
            "run_stopped_no_solution",
            {
                "challenge": args.challenge,
                "elapsed_seconds": time.monotonic() - started,
                "timeout_seconds": args.timeout_seconds,
            },
        )
        print("No solution found before timeout/stop.")
        print(f"ledger: {ledger.path}")
        print(f"ledger_verified: {ledger.verify()}")
        return 1

    ledger.append("solution_found", result)
    verified = ledger.verify()

    print("Solution found ✅")
    print(json.dumps(result, indent=2, sort_keys=True))
    print(f"ledger: {ledger.path}")
    print(f"ledger_verified: {verified}")

    return 0 if verified else 3


def clamp_workers(workers: int) -> int:
    if workers < 1:
        raise ValueError("--workers must be >= 1")
    cpu_count = os.cpu_count() or 1
    return min(workers, cpu_count)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sha256_usb_miner.py",
        description="USB-aware SHA-256 proof-of-work miner scaffold for owned hardware and education.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="Scan USB serial devices.")
    scan.set_defaults(func=command_scan)

    bench = sub.add_parser("benchmark", help="Benchmark local SHA-256 hashing rate.")
    bench.add_argument("--seconds", type=float, default=10.0)
    bench.add_argument("--workers", type=int, default=min(os.cpu_count() or 1, 4))
    bench.add_argument("--algorithm", choices=["sha256", "double-sha256"], default="double-sha256")
    bench.set_defaults(func=command_benchmark)

    mine = sub.add_parser("mine", help="Mine an educational SHA-256 proof-of-work challenge.")
    mine.add_argument("--challenge", required=True, help="Challenge string to mine against.")
    mine.add_argument("--bits", type=int, default=24, help="Required leading zero bits, max 32.")
    mine.add_argument("--workers", type=int, default=min(os.cpu_count() or 1, 4))
    mine.add_argument("--algorithm", choices=["sha256", "double-sha256"], default="double-sha256")
    mine.add_argument("--usb-index", type=int, default=None, help="Optional USB device index from scan.")
    mine.add_argument("--throttle-ms", type=int, default=0, help="Sleep this many ms every 1024 attempts.")
    mine.add_argument("--timeout-seconds", type=float, default=120.0)
    mine.set_defaults(func=command_mine)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
