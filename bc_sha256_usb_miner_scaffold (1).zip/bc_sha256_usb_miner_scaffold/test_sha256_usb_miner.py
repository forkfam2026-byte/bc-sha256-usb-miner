import json
from pathlib import Path

from sha256_usb_miner import (
    JsonlLedger,
    double_sha256,
    leading_zero_bits,
    meets_difficulty,
    build_work_payload,
)


def test_double_sha256_is_stable():
    assert double_sha256(b"abc").hex() == double_sha256(b"abc").hex()


def test_leading_zero_bits():
    assert leading_zero_bits(bytes.fromhex("00ff")) == 8
    assert leading_zero_bits(bytes.fromhex("0fff")) == 4
    assert leading_zero_bits(bytes.fromhex("ffff")) == 0


def test_meets_difficulty():
    assert meets_difficulty(bytes.fromhex("00ff"), 8)
    assert not meets_difficulty(bytes.fromhex("0fff"), 8)


def test_payload_is_deterministic():
    a = build_work_payload("x", 1, "usb", "double-sha256")
    b = build_work_payload("x", 1, "usb", "double-sha256")
    assert a == b


def test_ledger_detects_mutation(tmp_path):
    ledger = JsonlLedger(tmp_path)
    ledger.append("event", {"x": 1})
    assert ledger.verify()

    line = ledger.path.read_text().splitlines()[0]
    event = json.loads(line)
    event["payload"]["x"] = 2
    ledger.path.write_text(json.dumps(event) + "\n")

    assert not ledger.verify()
