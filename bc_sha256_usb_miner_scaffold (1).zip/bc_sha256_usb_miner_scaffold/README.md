# Black Caesar SHA-256 USB Miner Scaffold 👑⚙️

This is a **safe, explicit-run, owned-hardware-only** SHA-256 proof-of-work scaffold.

It is not malware.  
It does not autorun.  
It does not hide.  
It does not steal compute.  
It does not handle wallets or pool credentials.  
It does not activate USB ASICs through proprietary mining protocols.

## What it does

- Scans local USB serial devices.
- Lets the operator bind a proof-of-work run to a chosen USB device fingerprint.
- Mines an educational SHA-256 or double-SHA-256 challenge locally.
- Writes an append-only JSONL ledger.
- Verifies the ledger chain after benchmark/mine runs.

## Install

```bash
python -m venv .venv
source .venv/bin/activate   # macOS/Linux
# .venv\Scripts\activate    # Windows PowerShell

pip install -r requirements.txt
```

## Usage

Scan USB serial devices:

```bash
python sha256_usb_miner.py scan
```

Benchmark:

```bash
python sha256_usb_miner.py benchmark --seconds 10 --workers 4
```

Mine a local educational challenge:

```bash
python sha256_usb_miner.py mine --challenge "BLACK_CAESAR_CROWN_LAW" --bits 24 --workers 4
```

Bind the run to a detected USB device:

```bash
python sha256_usb_miner.py scan
python sha256_usb_miner.py mine --challenge "USB_BOUND_RUN" --bits 22 --usb-index 0 --workers 2
```

## Notes for real USB ASIC mining

Real Bitcoin mining requires:
- a SHA-256 ASIC device,
- device/vendor protocol support,
- pool mining via Stratum,
- wallet/payout configuration,
- thermal and electrical safety.

Use maintained miner software for that device. This scaffold is for safe Copilot/Ninja development: USB detection, proof-of-work logic, ledgering, and test discipline.

## Crown Law posture

```text
Explicit user run only ✅
Owned hardware only ✅
Local ledger ✅
No stealth ✅
No persistence ✅
No autorun ✅
No credential handling ✅
```
